import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ScatterChart, Scatter, ZAxis, Cell, LineChart, Line, ComposedChart, LabelList } from 'recharts';

const toolEfficiencyData = [
  { tool: 'Appvance', efficiency: 35, domain: 'Digital Commerce', hours: 130, projects: 2 },
  { tool: 'Microsoft Copilot', efficiency: 38.7, domain: 'Average', hours: 444, projects: 13 },
  { tool: 'Sidekick', efficiency: 22.9, domain: 'Average', hours: 1890, projects: 40 },
  { tool: 'GitHub Copilot', efficiency: 24.3, domain: 'Average', hours: 3023.5, projects: 28 },
  { tool: 'Cursor', efficiency: 27.6, domain: 'Average', hours: 906, projects: 7 },
  { tool: 'Codify', efficiency: 25.5, domain: 'Digital Commerce', hours: 76, projects: 2 },
  { tool: 'Figma AI', efficiency: 10, domain: 'Design Led P&E', hours: 40, projects: 1 },
  { tool: 'AI Assist: PO', efficiency: 40, domain: 'Marketing Tech', hours: 50, projects: 1 },
  { tool: 'AI Assist: QA', efficiency: 15.25, domain: 'Average', hours: 56, projects: 3 },
];

const efficiencyScatterData = [
  { efficiency: 35, hours: 130, tool: 'Appvance', size: 200 },
  { efficiency: 38.7, hours: 444, tool: 'Microsoft Copilot', size: 1300 },
  { efficiency: 22.9, hours: 1890, tool: 'Sidekick', size: 4000 },
  { efficiency: 24.3, hours: 3023.5, tool: 'GitHub Copilot', size: 2800 },
  { efficiency: 27.6, hours: 906, tool: 'Cursor', size: 700 },
  { efficiency: 40, hours: 50, tool: 'AI Assist: PO', size: 100 },
  { efficiency: 25.5, hours: 76, tool: 'Codify', size: 200 },
  { efficiency: 10, hours: 40, tool: 'Figma AI', size: 100 },
];

const domainEfficiencyData = [
  { domain: 'Digital Commerce', avgEfficiency: 20.3, totalHours: 3257.5, projects: 28 },
  { domain: 'Marketing Tech', avgEfficiency: 22.4, totalHours: 2460, projects: 26 },
  { domain: 'Experience Agency', avgEfficiency: 35.3, totalHours: 68, projects: 14 },
  { domain: 'Design Led P&E', avgEfficiency: 27.7, totalHours: 1118, projects: 7 },
];

const phaseBreakdownData = [
  { phase: 'Development', hours: 4113.5, percentage: 59.4 },
  { phase: 'Testing', hours: 1007.5, percentage: 14.5 },
  { phase: 'Planning & PMO', hours: 909, percentage: 13.1 },
  { phase: 'Design & Functional', hours: 485.5, percentage: 7.0 },
  { phase: 'Discovery', hours: 304, percentage: 4.4 },
  { phase: 'Change Management', hours: 22, percentage: 0.3 },
  { phase: 'Operate', hours: 4, percentage: 0.1 },
];

const COLORS = ['#93c5fd', '#c4b5fd', '#f9a8d4', '#fcd34d', '#86efac', '#7dd3fc', '#a5b4fc'];

export function EfficiencyAnalysis() {
  return (
    <div className="space-y-6">
      {/* Top Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <MetricCard
          title="Average Tool Efficiency"
          value="24.9%"
          subtitle="Across all tools"
          color="text-sky-500"
        />
        <MetricCard
          title="Most Efficient Tool"
          value="AI Assist: PO"
          subtitle="40% efficiency"
          color="text-emerald-500"
        />
        <MetricCard
          title="Highest Impact Domain"
          value="Digital Commerce"
          subtitle="3,257.5 hours saved"
          color="text-purple-400"
        />
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ChartCard title="Tool Efficiency Comparison">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={toolEfficiencyData.sort((a, b) => b.efficiency - a.efficiency)}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis 
                dataKey="tool" 
                angle={-45}
                textAnchor="end"
                height={120}
                fontSize={10}
              />
              <YAxis label={{ value: 'Efficiency %', angle: -90, position: 'insideLeft' }} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '8px' }}
                formatter={(value: number) => `${value}%`}
              />
              <Bar dataKey="efficiency" radius={[8, 8, 0, 0]}>
                {toolEfficiencyData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
                <LabelList dataKey="efficiency" position="top" formatter={(value: number) => `${value}%`} fontSize={10} />
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Efficiency vs Impact (Bubble Size = Clients)">
          <ResponsiveContainer width="100%" height={300}>
            <ScatterChart>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis 
                type="number" 
                dataKey="efficiency" 
                name="Efficiency" 
                unit="%" 
                label={{ value: 'Efficiency %', position: 'insideBottom', offset: -5 }}
              />
              <YAxis 
                type="number" 
                dataKey="hours" 
                name="Hours Saved" 
                label={{ value: 'Hours Saved', angle: -90, position: 'insideLeft' }}
              />
              <ZAxis type="number" dataKey="size" range={[100, 2000]} />
              <Tooltip 
                cursor={{ strokeDasharray: '3 3' }}
                contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '8px' }}
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    return (
                      <div className="bg-white p-3 rounded-lg shadow-lg border border-slate-200">
                        <p className="font-semibold text-slate-900">{payload[0].payload.tool}</p>
                        <p className="text-sm text-slate-600">Efficiency: {payload[0].payload.efficiency}%</p>
                        <p className="text-sm text-slate-600">Hours Saved: {payload[0].payload.hours}</p>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Scatter data={efficiencyScatterData} fill="#93c5fd">
                {efficiencyScatterData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Scatter>
            </ScatterChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ChartCard title="Average Efficiency by Domain">
          <ResponsiveContainer width="100%" height={300}>
            <ComposedChart data={domainEfficiencyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis 
                dataKey="domain" 
                angle={-20}
                textAnchor="end"
                height={80}
                fontSize={11}
              />
              <YAxis yAxisId="left" label={{ value: 'Efficiency %', angle: -90, position: 'insideLeft' }} />
              <YAxis yAxisId="right" orientation="right" label={{ value: 'Hours Saved', angle: 90, position: 'insideRight' }} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '8px' }}
              />
              <Legend />
              <Bar yAxisId="right" dataKey="totalHours" fill="#c4b5fd" radius={[8, 8, 0, 0]}>
                <LabelList dataKey="totalHours" position="top" fontSize={10} />
              </Bar>
              <Line yAxisId="left" type="monotone" dataKey="avgEfficiency" stroke="#86efac" strokeWidth={3} />
            </ComposedChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Hours Saved by Project Phase">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={phaseBreakdownData} layout="horizontal">
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis type="number" />
              <YAxis 
                dataKey="phase" 
                type="category" 
                width={130}
                fontSize={11}
              />
              <Tooltip 
                contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '8px' }}
                formatter={(value: number, name: string, props: any) => [
                  `${value} hrs (${props.payload.percentage}%)`,
                  'Hours Saved'
                ]}
              />
              <Bar dataKey="hours" radius={[0, 8, 8, 0]}>
                {phaseBreakdownData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
                <LabelList dataKey="hours" position="right" fontSize={10} />
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* Detailed Efficiency Table */}
      <ChartCard title="Tool Efficiency Details">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-200">
                <th className="text-left py-3 px-4 font-semibold text-slate-700">Tool</th>
                <th className="text-right py-3 px-4 font-semibold text-slate-700">Efficiency %</th>
                <th className="text-right py-3 px-4 font-semibold text-slate-700">Hours Saved</th>
                <th className="text-right py-3 px-4 font-semibold text-slate-700">Projects</th>
                <th className="text-left py-3 px-4 font-semibold text-slate-700">Domain</th>
                <th className="text-center py-3 px-4 font-semibold text-slate-700">Rating</th>
              </tr>
            </thead>
            <tbody>
              {toolEfficiencyData.sort((a, b) => b.efficiency - a.efficiency).map((tool, index) => (
                <tr key={index} className="border-b border-slate-100 hover:bg-slate-50">
                  <td className="py-3 px-4 text-slate-900">{tool.tool}</td>
                  <td className="py-3 px-4 text-right">
                    <span className={`font-semibold ${
                      tool.efficiency >= 30 ? 'text-emerald-500' : 
                      tool.efficiency >= 20 ? 'text-sky-500' : 
                      'text-amber-400'
                    }`}>
                      {tool.efficiency}%
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right text-slate-900">{tool.hours}</td>
                  <td className="py-3 px-4 text-right text-slate-900">{tool.projects}</td>
                  <td className="py-3 px-4 text-slate-600 text-sm">{tool.domain}</td>
                  <td className="py-3 px-4 text-center">
                    {tool.efficiency >= 35 ? '⭐⭐⭐' : tool.efficiency >= 25 ? '⭐⭐' : '⭐'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </ChartCard>
    </div>
  );
}

function MetricCard({ title, value, subtitle, color }: { 
  title: string; 
  value: string; 
  subtitle: string;
  color: string;
}) {
  return (
    <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
      <p className="text-slate-600 text-sm mb-2">{title}</p>
      <p className={`text-3xl font-bold ${color} mb-1`}>{value}</p>
      <p className="text-slate-500 text-xs">{subtitle}</p>
    </div>
  );
}

function ChartCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
      <h3 className="text-lg font-semibold text-slate-900 mb-4">{title}</h3>
      {children}
    </div>
  );
}