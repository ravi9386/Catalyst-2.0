import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, LabelList } from 'recharts';

const COLORS = ['#93c5fd', '#c4b5fd', '#f9a8d4', '#fcd34d', '#86efac', '#7dd3fc', '#a5b4fc', '#fca5a5', '#5eead4'];

const allToolsData = [
  { name: 'GitHub Copilot', hours: 3023.5, clients: 28, category: 'Development' },
  { name: 'Sidekick', hours: 1890, clients: 40, category: 'Project Management' },
  { name: 'Cursor', hours: 906, clients: 7, category: 'Development' },
  { name: 'Microsoft Copilot', hours: 444, clients: 13, category: 'Productivity' },
  { name: 'Appvance', hours: 130, clients: 2, category: 'Testing' },
  { name: 'Chat GPT Enterprise', hours: 125, clients: 2, category: 'General AI' },
  { name: 'Agentic QA', hours: 100, clients: 1, category: 'Testing' },
  { name: 'Playwright MCP', hours: 80, clients: 1, category: 'Testing' },
  { name: 'Codify', hours: 76, clients: 2, category: 'Development' },
  { name: 'AI Assist: QA', hours: 56, clients: 3, category: 'Testing' },
  { name: 'AI Assist: PO', hours: 50, clients: 1, category: 'Product' },
  { name: 'Figma AI', hours: 40, clients: 1, category: 'Design' },
];

const categoryData = [
  { category: 'Development', value: 4005.5 },
  { category: 'Project Management', value: 1890 },
  { category: 'Productivity', value: 444 },
  { category: 'Testing', value: 366 },
  { category: 'General AI', value: 125 },
  { category: 'Product', value: 50 },
  { category: 'Design', value: 40 },
];

const toolComparisonData = [
  { tool: 'GitHub Copilot', adoption: 28, hours: 302, efficiency: 25 },
  { tool: 'Sidekick', adoption: 40, hours: 189, efficiency: 21 },
  { tool: 'Cursor', adoption: 7, hours: 90, efficiency: 18 },
  { tool: 'Microsoft Copilot', adoption: 13, hours: 44, efficiency: 38 },
  { tool: 'Appvance', adoption: 2, hours: 13, efficiency: 35 },
];

export function ToolsAnalysis() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* All Tools Comparison */}
        <ChartCard title="All Tools - Hours Saved Distribution">
          <ResponsiveContainer width="100%" height={350}>
            <BarChart data={allToolsData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis 
                dataKey="name" 
                angle={-45}
                textAnchor="end"
                height={120}
                fontSize={11}
              />
              <YAxis />
              <Tooltip 
                contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '8px' }}
              />
              <Bar dataKey="hours" radius={[8, 8, 0, 0]}>
                {allToolsData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
                <LabelList dataKey="hours" position="top" formatter={(value: number) => value.toFixed(0)} fontSize={10} />
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* Category Distribution */}
        <ChartCard title="Hours Saved by Tool Category">
          <ResponsiveContainer width="100%" height={350}>
            <PieChart>
              <Pie
                data={categoryData}
                cx="50%"
                cy="50%"
                labelLine={true}
                label={({ category, value }) => `${category}: ${value}hrs`}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
              >
                {categoryData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '8px' }}
              />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* Tool Performance Radar */}
      <ChartCard title="Top 5 Tools - Multi-Dimensional Performance">
        <ResponsiveContainer width="100%" height={400}>
          <RadarChart data={toolComparisonData}>
            <PolarGrid stroke="#e2e8f0" />
            <PolarAngleAxis dataKey="tool" fontSize={12} />
            <PolarRadiusAxis angle={90} />
            <Radar name="Adoption (Clients)" dataKey="adoption" stroke="#93c5fd" fill="#93c5fd" fillOpacity={0.3} />
            <Radar name="Hours Saved (÷10)" dataKey="hours" stroke="#c4b5fd" fill="#c4b5fd" fillOpacity={0.3} />
            <Radar name="Efficiency %" dataKey="efficiency" stroke="#86efac" fill="#86efac" fillOpacity={0.3} />
            <Legend />
            <Tooltip 
              contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '8px' }}
            />
          </RadarChart>
        </ResponsiveContainer>
      </ChartCard>

      {/* Tool Details Table */}
      <ChartCard title="Detailed Tool Breakdown">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-200">
                <th className="text-left py-3 px-4 font-semibold text-slate-700">Tool Name</th>
                <th className="text-right py-3 px-4 font-semibold text-slate-700">Hours Saved</th>
                <th className="text-right py-3 px-4 font-semibold text-slate-700">Clients</th>
                <th className="text-left py-3 px-4 font-semibold text-slate-700">Category</th>
              </tr>
            </thead>
            <tbody>
              {allToolsData.map((tool, index) => (
                <tr key={index} className="border-b border-slate-100 hover:bg-slate-50">
                  <td className="py-3 px-4 text-slate-900">{tool.name}</td>
                  <td className="py-3 px-4 text-right text-slate-900">{tool.hours.toFixed(1)}</td>
                  <td className="py-3 px-4 text-right text-slate-900">{tool.clients}</td>
                  <td className="py-3 px-4">
                    <span className="inline-block px-2 py-1 rounded-full text-xs bg-blue-50 text-blue-600">
                      {tool.category}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </ChartCard>
    </div>
  );
}

function ChartCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
      <h3 className="text-lg font-semibold text-slate-900 mb-4">{title}</h3>
      {children}
    </div>
  );
}