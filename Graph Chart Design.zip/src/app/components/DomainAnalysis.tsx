import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line, ComposedChart, Area, LabelList } from 'recharts';

const domainComparisonData = [
  { 
    domain: 'Digital Commerce', 
    clients: 25, 
    projects: 28,
    totalHoursSaved: 3257.5,
    projectsUsingAI: 25,
    projectsNotUsingAI: 3,
    avgScope: 38357.11
  },
  { 
    domain: 'Marketing Tech', 
    clients: 24, 
    projects: 26,
    totalHoursSaved: 2460,
    projectsUsingAI: 18,
    projectsNotUsingAI: 8,
    avgScope: 18402.62
  },
  { 
    domain: 'Experience Agency', 
    clients: 14, 
    projects: 14,
    totalHoursSaved: 68,
    projectsUsingAI: 7,
    projectsNotUsingAI: 7,
    avgScope: 1303.57
  },
  { 
    domain: 'Design Led P&E', 
    clients: 7, 
    projects: 7,
    totalHoursSaved: 1118,
    projectsUsingAI: 1,
    projectsNotUsingAI: 1,
    avgScope: 5686.03
  },
];

const domainToolsData = [
  { domain: 'Digital Commerce', GitHub: 1430.5, Microsoft: 159, Sidekick: 1111, Others: 557 },
  { domain: 'Marketing Tech', GitHub: 765, Microsoft: 195, Sidekick: 560, Others: 940 },
  { domain: 'Experience Agency', GitHub: 0, Microsoft: 0, Sidekick: 68, Others: 0 },
  { domain: 'Design Led P&E', GitHub: 828, Microsoft: 90, Sidekick: 151, Others: 49 },
];

const aiAdoptionData = [
  { domain: 'Digital Commerce', adopted: 89, notAdopted: 11 },
  { domain: 'Marketing Tech', adopted: 69, notAdopted: 31 },
  { domain: 'Experience Agency', adopted: 50, notAdopted: 50 },
  { domain: 'Design Led P&E', adopted: 50, notAdopted: 50 },
];

export function DomainAnalysis() {
  return (
    <div className="space-y-6">
      {/* Domain Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {domainComparisonData.map((domain, index) => (
          <DomainCard key={index} domain={domain} />
        ))}
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ChartCard title="Total Hours Saved by Domain">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={domainComparisonData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis 
                dataKey="domain" 
                angle={-20}
                textAnchor="end"
                height={80}
                fontSize={11}
              />
              <YAxis />
              <Tooltip 
                contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '8px' }}
              />
              <Bar dataKey="totalHoursSaved" fill="#93c5fd" radius={[8, 8, 0, 0]}>
                <LabelList dataKey="totalHoursSaved" position="top" />
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Projects & Clients by Domain">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={domainComparisonData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis 
                dataKey="domain" 
                angle={-20}
                textAnchor="end"
                height={80}
                fontSize={11}
              />
              <YAxis />
              <Tooltip 
                contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '8px' }}
              />
              <Legend />
              <Bar dataKey="clients" fill="#c4b5fd" radius={[8, 8, 0, 0]}>
                <LabelList dataKey="clients" position="top" />
              </Bar>
              <Bar dataKey="projects" fill="#f9a8d4" radius={[8, 8, 0, 0]}>
                <LabelList dataKey="projects" position="top" />
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* Tool Distribution by Domain */}
      <ChartCard title="Tool Hours Distribution Across Domains">
        <ResponsiveContainer width="100%" height={350}>
          <BarChart data={domainToolsData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
            <XAxis 
              dataKey="domain" 
              angle={-20}
              textAnchor="end"
              height={80}
              fontSize={11}
            />
            <YAxis />
            <Tooltip 
              contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '8px' }}
            />
            <Legend />
            <Bar dataKey="GitHub" stackId="a" fill="#93c5fd" />
            <Bar dataKey="Microsoft" stackId="a" fill="#c4b5fd" />
            <Bar dataKey="Sidekick" stackId="a" fill="#86efac" />
            <Bar dataKey="Others" stackId="a" fill="#fcd34d" />
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>

      {/* AI Adoption Rate */}
      <ChartCard title="AI Tool Adoption Rate by Domain (%)">
        <ResponsiveContainer width="100%" height={300}>
          <ComposedChart data={aiAdoptionData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
            <XAxis 
              dataKey="domain" 
              angle={-20}
              textAnchor="end"
              height={80}
              fontSize={11}
            />
            <YAxis />
            <Tooltip 
              contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '8px' }}
            />
            <Legend />
            <Bar dataKey="adopted" stackId="a" fill="#86efac" radius={[8, 8, 0, 0]}>
              <LabelList dataKey="adopted" position="inside" fill="#fff" />
            </Bar>
            <Bar dataKey="notAdopted" stackId="a" fill="#fca5a5" radius={[8, 8, 0, 0]}>
              <LabelList dataKey="notAdopted" position="inside" fill="#fff" />
            </Bar>
            <Line type="monotone" dataKey="adopted" stroke="#22c55e" strokeWidth={3} />
          </ComposedChart>
        </ResponsiveContainer>
      </ChartCard>
    </div>
  );
}

function DomainCard({ domain }: { domain: typeof domainComparisonData[0] }) {
  return (
    <div className="bg-white rounded-xl p-5 shadow-sm border border-slate-200">
      <h4 className="font-semibold text-slate-900 mb-3 text-sm">{domain.domain}</h4>
      <div className="space-y-2">
        <div className="flex justify-between items-center">
          <span className="text-xs text-slate-600">Clients</span>
          <span className="font-semibold text-slate-900">{domain.clients}</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-xs text-slate-600">Projects</span>
          <span className="font-semibold text-slate-900">{domain.projects}</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-xs text-slate-600">Hours Saved</span>
          <span className="font-semibold text-emerald-500">{domain.totalHoursSaved}</span>
        </div>
        <div className="flex justify-between items-center pt-2 border-t border-slate-100">
          <span className="text-xs text-slate-600">AI Adoption</span>
          <span className="text-xs font-semibold text-sky-500">
            {Math.round((domain.projectsUsingAI / domain.projects) * 100)}%
          </span>
        </div>
      </div>
    </div>
  );
}

function ChartCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
      <h3 className="text-lg font-semibold text-slate-900 mb-4">{title}</h3>
      {children}
    </div>
  );
}