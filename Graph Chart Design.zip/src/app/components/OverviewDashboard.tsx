import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell, LabelList } from 'recharts';
import { Users, FolderKanban, Layers, TrendingUp } from 'lucide-react';

const COLORS = ['#93c5fd', '#c4b5fd', '#f9a8d4', '#fcd34d', '#86efac', '#7dd3fc', '#a5b4fc'];

const topToolsHoursData = [
  { name: 'GitHub Copilot', hours: 3023.5 },
  { name: 'Sidekick', hours: 1890 },
  { name: 'Cursor', hours: 906 },
  { name: 'Microsoft Copilot', hours: 444 },
  { name: 'Appvance', hours: 130 },
  { name: 'Chat GPT Enterprise', hours: 125 },
  { name: 'Agentic QA', hours: 100 },
];

const topToolsClientsData = [
  { name: 'Sidekick', clients: 40 },
  { name: 'GitHub Copilot', clients: 28 },
  { name: 'Microsoft Copilot', clients: 13 },
  { name: 'Cursor', clients: 7 },
  { name: 'AI Assist: QA', clients: 3 },
  { name: 'Appvance', clients: 2 },
  { name: 'Chat GPT', clients: 2 },
];

const domainSummaryData = [
  { domain: 'Digital Commerce', clients: 25, projects: 28 },
  { domain: 'Marketing Tech', clients: 24, projects: 26 },
  { domain: 'Experience Agency', clients: 14, projects: 14 },
  { domain: 'Design Led P&E', clients: 7, projects: 7 },
];

export function OverviewDashboard() {
  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          icon={<Users className="size-5" />}
          title="Total Unique Clients"
          value="71"
          color="bg-blue-400"
        />
        <StatCard
          icon={<FolderKanban className="size-5" />}
          title="Total Projects"
          value="75"
          color="bg-purple-400"
        />
        <StatCard
          icon={<Layers className="size-5" />}
          title="AI Tools Used"
          value="13"
          color="bg-pink-400"
        />
        <StatCard
          icon={<TrendingUp className="size-5" />}
          title="Total Hours Saved"
          value="6,932.5"
          color="bg-green-400"
        />
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ChartCard title="Top Tools by Hours Saved">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={topToolsHoursData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis 
                dataKey="name" 
                angle={-45}
                textAnchor="end"
                height={100}
                fontSize={12}
              />
              <YAxis />
              <Tooltip 
                contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '8px' }}
              />
              <Bar dataKey="hours" fill="#93c5fd" radius={[8, 8, 0, 0]}>
                <LabelList dataKey="hours" position="top" formatter={(value: number) => value.toFixed(0)} />
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Tools by Number of Clients">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={topToolsClientsData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis 
                dataKey="name" 
                angle={-45}
                textAnchor="end"
                height={100}
                fontSize={12}
              />
              <YAxis />
              <Tooltip 
                contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '8px' }}
              />
              <Bar dataKey="clients" fill="#c4b5fd" radius={[8, 8, 0, 0]}>
                <LabelList dataKey="clients" position="top" />
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* Domain Summary */}
      <ChartCard title="Domain-Level Summary">
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={domainSummaryData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
            <XAxis 
              dataKey="domain" 
              angle={-20}
              textAnchor="end"
              height={80}
              fontSize={12}
            />
            <YAxis />
            <Tooltip 
              contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '8px' }}
            />
            <Legend />
            <Bar dataKey="clients" fill="#93c5fd" radius={[8, 8, 0, 0]}>
              <LabelList dataKey="clients" position="top" />
            </Bar>
            <Bar dataKey="projects" fill="#86efac" radius={[8, 8, 0, 0]}>
              <LabelList dataKey="projects" position="top" />
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>
    </div>
  );
}

function StatCard({ icon, title, value, color }: { icon: React.ReactNode; title: string; value: string; color: string }) {
  return (
    <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <p className="text-slate-600 text-sm mb-1">{title}</p>
          <p className="text-3xl font-bold text-slate-900">{value}</p>
        </div>
        <div className={`${color} rounded-lg p-3 text-white`}>
          {icon}
        </div>
      </div>
    </div>
  );
}

function ChartCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
      <h3 className="text-lg font-semibold text-slate-900 mb-4">{title}</h3>
      {children}
    </div>
  );
}