import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { OverviewDashboard } from './components/OverviewDashboard';
import { ToolsAnalysis } from './components/ToolsAnalysis';
import { DomainAnalysis } from './components/DomainAnalysis';
import { EfficiencyAnalysis } from './components/EfficiencyAnalysis';

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4 md:p-8">
      <div className="max-w-[1600px] mx-auto">
        <header className="mb-8">
          <h1 className="text-4xl font-bold text-slate-900 mb-2">
            AM&C Level Details - January 2026
          </h1>
          <p className="text-slate-600">
            AI, Machine Learning & Cognitive Analytics Dashboard
          </p>
        </header>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="mb-6">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="tools">Tools Analysis</TabsTrigger>
            <TabsTrigger value="domains">Domain Comparison</TabsTrigger>
            <TabsTrigger value="efficiency">Efficiency Metrics</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <OverviewDashboard />
          </TabsContent>

          <TabsContent value="tools">
            <ToolsAnalysis />
          </TabsContent>

          <TabsContent value="domains">
            <DomainAnalysis />
          </TabsContent>

          <TabsContent value="efficiency">
            <EfficiencyAnalysis />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
