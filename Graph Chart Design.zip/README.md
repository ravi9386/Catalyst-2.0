
  # Graph Chart Design

  This is a code bundle for Graph Chart Design. The original project is available at https://www.figma.com/design/ISUo0d1dhfZChG67j97HOW/Graph-Chart-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  